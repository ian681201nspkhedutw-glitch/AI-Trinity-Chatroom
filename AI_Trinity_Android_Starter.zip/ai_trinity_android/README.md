# AI Trinity Chatroom (Android starter)

A native Android (Kotlin + Jetpack Compose) starter app with a Node.js backend.
It connects to OpenAI, Gemini, and DeepSeek through their official APIs. API keys stay
on the backend; never put provider keys in the Android app.

## What is included
- Android chat UI with three AI identities.
- Mixed mode: choose a speaker or let all three speak in sequence.
- Bounded discussion rounds (1–5) to avoid runaway API costs.
- Backend adapters for OpenAI Responses, Gemini `generateContent`, and DeepSeek Chat Completions.
- `.env.example`, Dockerfile, and setup instructions.

## Requirements
- Android Studio (current stable), JDK 17, Android SDK 35.
- Node.js 20+ on a computer/server.
- API keys and billing/credits where required for each provider.

## 1. Start the backend
```bash
cd backend
cp .env.example .env
# Edit .env and add your provider API keys.
npm install
npm start
```
The server listens on port 8787. For local Android emulator use `http://10.0.2.2:8787`.
For a physical phone, the phone and computer must be on the same network; set
`BASE_URL` in `app/build.gradle.kts` to your computer's LAN IP, e.g.
`http://192.168.1.20:8787`.

For deployment, use HTTPS and a secret manager. Do not expose port 8787 publicly
without authentication, rate limiting, and abuse protection.

## 2. Open the Android app
Open the `android` folder in Android Studio, let Gradle sync, then Run on an emulator
or Android device.

## 3. Provider setup
- OpenAI: create an API key in your OpenAI Platform project.
- Gemini: create a Gemini API key in Google AI Studio.
- DeepSeek: create an API key in the DeepSeek platform.

The app cannot call consumer ChatGPT/Gemini/DeepSeek chat subscriptions directly.
It uses separate developer APIs, which may have separate billing and limits.

## Mixed mode
- `單一 AI`: only the selected provider responds.
- `三方接力`: ChatGPT → Gemini → DeepSeek, each sees the conversation so far.
- `自由討論`: same bounded relay, with a discussion instruction asking each AI to react
  to the previous speakers. The user can choose 1–5 rounds. This is intentionally bounded;
  it does not run forever.

## Notes / next steps
This is a starter implementation, not a published APK or hosted service. You still need
to add your own API keys, run/deploy the backend, and build/sign the APK. For public use,
add user accounts, per-user quotas, persistent database storage, and moderation controls.
