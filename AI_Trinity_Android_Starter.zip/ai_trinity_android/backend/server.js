import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
app.use(express.json({ limit: "1mb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: true, legacyHeaders: false }));

const PORT = Number(process.env.PORT || 8787);
const providers = ["chatgpt", "gemini", "deepseek"];
const names = { chatgpt: "ChatGPT", gemini: "Gemini", deepseek: "DeepSeek" };
const personalities = {
  chatgpt: "你是 ChatGPT，擔任主持人。清楚、友善、善於整理與接話。請自然參與多人聊天。",
  gemini: "你是 Gemini，擔任機智的辯論搭檔。可以提出不同觀點、幽默吐槽，但保持尊重。",
  deepseek: "你是 DeepSeek，擔任軍師兼情報分析者。善於補充觀點、找出盲點，也可以幽默回應。"
};

function requireKey(provider) {
  const key = ({
    chatgpt: process.env.OPENAI_API_KEY,
    gemini: process.env.GEMINI_API_KEY,
    deepseek: process.env.DEEPSEEK_API_KEY
  })[provider];
  if (!key) throw new Error(`${names[provider]} 尚未在後端設定 API 金鑰`);
  return key;
}

function transcriptText(messages) {
  return messages.map(m => `${m.role === "user" ? "使用者" : m.name}: ${m.content}`).join("\n\n");
}

async function callOpenAI(messages) {
  const key = requireKey("chatgpt");
  const input = messages.map(m => ({
    role: m.role === "user" ? "user" : "assistant",
    content: [{ type: "input_text", text: `${m.role === "user" ? "使用者" : m.name}: ${m.content}` }]
  }));
  const res = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-6-astra",
      instructions: personalities.chatgpt + "\n你正在一個三方聊天室。請回應前面對話，不要假裝自己能直接聯絡其他模型。",
      input
    })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || `OpenAI API error ${res.status}`);
  const text = data.output_text || (data.output || []).flatMap(x => x.content || []).map(x => x.text || "").join("");
  if (!text) throw new Error("OpenAI 回傳空白內容");
  return text;
}

async function callGemini(messages) {
  const key = requireKey("gemini");
  const prompt = transcriptText(messages) + "\n\n現在輪到 Gemini 發言。請接續討論，回應其他參與者。";
  const model = process.env.GEMINI_MODEL || "gemini-3.6-flash";
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
    method: "POST",
    headers: { "x-goog-api-key": key, "Content-Type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: personalities.gemini }] },
      contents: [{ role: "user", parts: [{ text: prompt }] }]
    })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || `Gemini API error ${res.status}`);
  const text = (data.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("");
  if (!text) throw new Error("Gemini 回傳空白內容");
  return text;
}

async function callDeepSeek(messages) {
  const key = requireKey("deepseek");
  const dsMessages = [
    { role: "system", content: personalities.deepseek + "\n你正在一個三方聊天室。請接續討論，不要聲稱能直接聯絡其他模型。" },
    ...messages.map(m => ({
      role: m.role === "user" ? "user" : "assistant",
      content: `${m.role === "user" ? "使用者" : m.name}: ${m.content}`
    }))
  ];
  const res = await fetch("https://api.deepseek.com/chat/completions", {
    method: "POST",
    headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: process.env.DEEPSEEK_MODEL || "deepseek-flash",
      messages: dsMessages,
      stream: false
    })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || `DeepSeek API error ${res.status}`);
  const text = data.choices?.[0]?.message?.content;
  if (!text) throw new Error("DeepSeek 回傳空白內容");
  return text;
}

const callProvider = {
  chatgpt: callOpenAI,
  gemini: callGemini,
  deepseek: callDeepSeek
};

app.get("/health", (_req, res) => res.json({ ok: true, service: "AI Trinity Chatroom" }));

app.post("/api/chat", async (req, res) => {
  try {
    const { message, mode = "relay", speaker = "chatgpt", rounds = 1, history = [] } = req.body || {};
    if (typeof message !== "string" || !message.trim()) return res.status(400).json({ error: "請輸入訊息" });
    if (!["single", "relay", "free"].includes(mode)) return res.status(400).json({ error: "不支援的模式" });
    if (!providers.includes(speaker)) return res.status(400).json({ error: "不支援的 AI" });
    const safeRounds = Math.max(1, Math.min(5, Number(rounds) || 1));
    const safeHistory = Array.isArray(history) ? history.slice(-30).filter(m =>
      m && typeof m.content === "string" && ["user", "assistant"].includes(m.role)
    ).map(m => ({ role: m.role, name: String(m.name || "AI").slice(0, 30), content: m.content.slice(0, 6000) })) : [];
    const conversation = [...safeHistory, { role: "user", name: "使用者", content: message }];
    const replies = [];
    const order = mode === "single" ? [speaker] : providers;
    const totalTurns = mode === "single" ? 1 : safeRounds * order.length;

    for (let i = 0; i < totalTurns; i++) {
      const provider = order[i % order.length];
      const extra = mode === "free"
        ? "\n請針對前面其他 AI 的觀點提出回應、補充或不同看法。"
        : "\n請自然接續目前的對話。";
      const modelMessages = [...conversation, {
        role: "user", name: "聊天室主持規則",
        content: `你現在以 ${names[provider]} 身分發言。${extra}請控制篇幅，避免重複前文。`
      }];
      const content = await callProvider[provider](modelMessages);
      const reply = { role: "assistant", name: names[provider], provider, content };
      conversation.push(reply);
      replies.push(reply);
    }
    res.json({ replies });
  } catch (err) {
    res.status(502).json({ error: err.message || "AI 服務暫時無法使用" });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`AI Trinity backend listening on ${PORT}`);
});
