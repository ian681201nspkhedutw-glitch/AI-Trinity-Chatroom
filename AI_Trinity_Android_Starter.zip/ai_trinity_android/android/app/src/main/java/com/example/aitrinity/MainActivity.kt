package com.example.aitrinity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatMessage(val role: String, val name: String, val content: String, val provider: String = "")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TrinityApp() }
    }
}

private val http = OkHttpClient.Builder()
    .connectTimeout(20, TimeUnit.SECONDS)
    .readTimeout(180, TimeUnit.SECONDS)
    .build()

private suspend fun sendToBackend(
    message: String, mode: String, speaker: String, rounds: Int, history: List<ChatMessage>
): List<ChatMessage> = withContext(Dispatchers.IO) {
    val hist = JSONArray()
    history.takeLast(30).forEach {
        hist.put(JSONObject().put("role", it.role).put("name", it.name).put("content", it.content))
    }
    val payload = JSONObject()
        .put("message", message)
        .put("mode", mode)
        .put("speaker", speaker)
        .put("rounds", rounds)
        .put("history", hist)
    val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
    val request = Request.Builder().url(BuildConfig.BASE_URL + "api/chat").post(body).build()
    http.newCall(request).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        if (!response.isSuccessful) {
            val err = runCatching { JSONObject(raw).optString("error") }.getOrDefault("伺服器錯誤")
            throw IllegalStateException(err.ifBlank { "HTTP ${response.code}" })
        }
        val arr = JSONObject(raw).getJSONArray("replies")
        (0 until arr.length()).map { i ->
            val item = arr.getJSONObject(i)
            ChatMessage("assistant", item.optString("name"), item.optString("content"), item.optString("provider"))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrinityApp() {
    val messages = remember { mutableStateListOf<ChatMessage>() }
    var input by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("relay") }
    var speaker by remember { mutableStateOf("chatgpt") }
    var rounds by remember { mutableIntStateOf(1) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF9CC7FF),
        secondary = Color(0xFFB8C8E8),
        background = Color(0xFF10131A),
        surface = Color(0xFF191E28)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("AI 三方聊天室", fontWeight = FontWeight.Bold)
                            Text("ChatGPT · Gemini · DeepSeek", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )
            },
            bottomBar = {
                Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = input, onValueChange = { input = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("對大家說點什麼……") },
                            maxLines = 4
                        )
                        IconButton(
                            enabled = input.isNotBlank() && !busy,
                            onClick = {
                                val text = input.trim()
                                input = ""
                                val old = messages.toList()
                                messages.add(ChatMessage("user", "你", text))
                                busy = true
                                error = null
                                scope.launch {
                                    try {
                                        val replies = sendToBackend(text, mode, speaker, rounds, old)
                                        messages.addAll(replies)
                                    } catch (e: Exception) {
                                        error = e.message ?: "連線失敗"
                                    } finally { busy = false }
                                }
                            }
                        ) { Icon(Icons.Default.Send, contentDescription = "送出") }
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)) {
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeChip("單一 AI", mode == "single") { mode = "single" }
                    ModeChip("三方接力", mode == "relay") { mode = "relay" }
                    ModeChip("自由討論", mode == "free") { mode = "free" }
                }
                if (mode == "single") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("chatgpt" to "ChatGPT", "gemini" to "Gemini", "deepseek" to "DeepSeek").forEach { (id, label) ->
                            FilterChip(selected = speaker == id, onClick = { speaker = id }, label = { Text(label) })
                        }
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("討論輪數", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(12.dp))
                        (1..5).forEach { n ->
                            FilterChip(selected = rounds == n, onClick = { rounds = n }, label = { Text("$n") })
                            Spacer(Modifier.width(4.dp))
                        }
                    }
                }
                if (busy) {
                    LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 4.dp))
                    Text("AI 正在依序交流……", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
                error?.let { Text("連線提示：$it", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp)) }
                if (messages.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("☕", fontSize = 44.sp)
                            Text("三位 AI 已在聊天室待命", fontWeight = FontWeight.SemiBold)
                            Text("輸入訊息，開始你們的第一場三方對話。", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(messages) { msg -> MessageBubble(msg) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == "user"
    val tint = when (message.provider) {
        "chatgpt" -> Color(0xFF244D43)
        "gemini" -> Color(0xFF263D63)
        "deepseek" -> Color(0xFF4A315E)
        else -> MaterialTheme.colorScheme.surface
    }
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Text(message.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Surface(
            color = if (isUser) MaterialTheme.colorScheme.primaryContainer else tint,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            Text(
                message.content,
                modifier = Modifier.padding(12.dp),
                color = if (isUser) MaterialTheme.colorScheme.onPrimaryContainer else Color.White
            )
        }
    }
}
